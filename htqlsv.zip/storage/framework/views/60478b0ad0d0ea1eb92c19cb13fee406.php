<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Danh sách Môn Học</h2>

    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.monhocs.create')); ?>" class="btn btn-primary mb-3">Thêm Môn Học</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tên Môn Học</th>
                <th>Mã Môn Học</th>
                <th>Số Tín Chỉ</th>
                <th>Giảng Viên</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $monHocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($mh->id); ?></td>
                <td><?php echo e($mh->ten_mon_hoc); ?></td>
                <td><?php echo e($mh->ma_mon_hoc); ?></td>
                <td><?php echo e($mh->so_tin_chi); ?></td>
                <td><?php echo e(optional($mh->giangVien)->ho_ten); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.monhocs.edit', $mh->id)); ?>" class="btn btn-warning btn-sm">Sửa</a>
                    <form action="<?php echo e(route('admin.monhocs.destroy', $mh->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa?')">Xóa</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\admin\monhocs\index.blade.php ENDPATH**/ ?>