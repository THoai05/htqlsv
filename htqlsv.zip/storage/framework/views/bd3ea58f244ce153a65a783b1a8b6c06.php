<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card shadow-lg p-4">
        <h2 class="text-center mb-4">Chỉnh sửa User</h2>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.users.update', $user->user_ID)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label class="form-label">Username:</label>
                <input type="text" name="username" value="<?php echo e(old('username', $user->username)); ?>" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Mật khẩu mới (nếu muốn thay đổi):</label>
                <input type="password" name="password" class="form-control" placeholder="Để trống nếu không đổi">
            </div>

            <div class="mb-3">
                <label class="form-label">Role:</label>
                <select name="role" class="form-select" required>
                    <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Admin</option>
                    <option value="sinhvien" <?php echo e($user->role === 'sinhvien' ? 'selected' : ''); ?>>Sinh viên</option>
                    <option value="giangvien" <?php echo e($user->role === 'giangvien' ? 'selected' : ''); ?>>Giảng viên</option>
                </select>
            </div>

            <button type="submit" class="btn btn-success w-100">Cập nhật</button>
        </form>

        <div class="text-center mt-3">
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary">Quay lại</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\admin\users\edit.blade.php ENDPATH**/ ?>