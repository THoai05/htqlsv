<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Thêm Lớp Học Phần</h1>

    <!-- Hiển thị lỗi nếu có -->
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.lichhoc.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="tenlop">Tên Lớp:</label>
            <input type="text" name="tenlop" id="tenlop" class="form-control" placeholder="Nhập tên lớp" required>
        </div>

        <div class="form-group">
            <label for="mamonhoc">Môn Học:</label>
            <select name="mamonhoc" id="mamonhoc" class="form-control" required>
                <option value="">-- Chọn môn học --</option>
                <?php $__currentLoopData = $monhocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($mon->id); ?>"><?php echo e($mon->ten_mon_hoc); ?> (<?php echo e($mon->ma_mon_hoc); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="phonghoc_ID">Phòng Học:</label>
            <select name="phonghoc_ID" id="phonghoc_ID" class="form-control" required>
                <option value="">-- Chọn phòng học --</option>
                <?php $__currentLoopData = $phonghocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($phong->phonghoc_ID); ?>"><?php echo e($phong->tenphonghoc); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="giangvien_ID">Giảng Viên:</label>
            <select name="giangvien_ID" id="giangvien_ID" class="form-control" required>
                <option value="">-- Chọn giảng viên --</option>
                <?php $__currentLoopData = $giangviens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($gv->id); ?>"><?php echo e($gv->ho_ten); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="soluongsv">Số Lượng Sinh Viên:</label>
            <input type="number" name="soluongsv" id="soluongsv" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="thoigianbatdau">Thời Gian Bắt Đầu:</label>
            <input type="date" name="thoigianbatdau" id="thoigianbatdau" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="thoigianketthuc">Thời Gian Kết Thúc:</label>
            <input type="date" name="thoigianketthuc" id="thoigianketthuc" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="ngayhoc">Ngày Học:</label>
            <input type="text" name="ngayhoc" id="ngayhoc" class="form-control" placeholder="Ví dụ: Thứ 2, Thứ 4"
                required>
        </div>

        <div class="form-group">
            <label for="tietbatdau">Tiết Bắt Đầu:</label>
            <input type="number" name="tietbatdau" id="tietbatdau" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="tietketthuc">Tiết Kết Thúc:</label>
            <input type="number" name="tietketthuc" id="tietketthuc" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Lưu</button>
        <a href="<?php echo e(route('admin.lichhoc.index')); ?>" class="btn btn-secondary">Hủy</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\admin\lichhoc\create.blade.php ENDPATH**/ ?>