<?php $__env->startSection('scripts'); ?>
    <script>
        document.querySelectorAll('.form-dangky').forEach(form => {
            form.addEventListener('submit', function (e) {
                e.preventDefault(); // Chặn submit mặc định

                Swal.fire({
                    title: 'Xác nhận xóa học phần',
                    text: 'Bạn có chắc chắn muốn xóa học phần này?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Đồng ý',
                    cancelButtonText: 'Huỷ bỏ',
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit(); // Submit nếu người dùng xác nhận
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Các lớp học phần của tôi</h2>
        <?php if(session('success1')): ?>
            <div class="alert alert-success"><?php echo e(session('success1')); ?></div>
        <?php endif; ?>
        <a href="<?php echo e(route('student.dangkilophocphan.index')); ?>"
            class="btn btn-danger btn-lg fw-bold shadow px-4 py-2 my-4 rounded-pill ">
            🔥 Đăng ký học phần
        </a>
        <table class="table table-bordered table-striped">
            <thead class="table-primary">
                <tr>
                    <th>Tên lớp học phần</th>
                    <th>Môn học</th>
                    <th>Số tín chỉ</th>
                    <th>Phòng học</th>
                    <th>Ngày học</th>
                    <th>Tiết bắt đầu</th>
                    <th>Tiết kết thúc</th>
                    <th>Xem điểm</th>
                    <th>Xóa học phần</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $lophocphans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($lop->monhoc->khoa == $sinhvien->khoa): ?>
                        <tr>
                            <td><?php echo e($lop->tenlop); ?></td>
                            <td><?php echo e($lop->monhoc->ten_mon_hoc ?? 'Chưa có'); ?></td>
                            <td><?php echo e($lop->monhoc->so_tin_chi); ?></td>
                            <td><?php echo e($lop->phonghoc->tenphonghoc ?? 'Chưa có'); ?></td>
                            <td><?php echo e($lop->ngayhoc); ?></td>
                            <td><?php echo e($lop->tietbatdau); ?></td>
                            <td><?php echo e($lop->tietketthuc); ?></td>
                            <td>
                                <a href="<?php echo e(route('student.diem.show', ['lophoc_ID' => $lop->lophoc_ID, 'sinhvien_ID' => $sinhvien->sinhvien_ID])); ?>"
                                    class="btn btn-info btn-sm" style="display: inline-flex; align-items: center;">
                                    <img src="<?php echo e(asset('images/find.png')); ?>"
                                        style="width: 20px; height: 20px; margin-right: 5px;" />
                                    Xem Điểm
                                </a>

                            </td>
                            <td>
                                <form class="form-dangky"
                                    action="<?php echo e(route('student.hocphan.delete', ['lophoc_ID' => $lop->lophoc_ID, 'sinhvien_ID' => $sinhvien->sinhvien_ID])); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm"
                                        style="display: inline-flex; align-items: center;">
                                        <i class="fas fa-trash-alt" style="margin-right: 5px;"></i> Xóa
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\student\lophocphan_list.blade.php ENDPATH**/ ?>