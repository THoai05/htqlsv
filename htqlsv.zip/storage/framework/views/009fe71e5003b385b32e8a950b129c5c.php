<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="mb-4 text-primary">Thông Tin Điểm Của Sinh Viên môn học : <?php echo e($lophocphan->monhoc->ten_mon_hoc); ?></h2>
    <p><strong>Số tín chỉ:</strong> <?php echo e($lophocphan->monhoc->so_tin_chi); ?></p>
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i><?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <?php if($diem): ?>
    <div class="card shadow-sm">
        <div class="card-body">
            <h5 class="card-title text-success">Điểm chi tiết</h5>
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Điểm 15 phút 1:</strong> <?php echo e($diem->diem_15p_1); ?></p>
                    <p><strong>Điểm 15 phút 2:</strong> <?php echo e($diem->diem_15p_2); ?></p>
                    <p><strong>Điểm 15 phút 3:</strong> <?php echo e($diem->diem_15p_3); ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Điểm giữa kỳ:</strong> <?php echo e($diem->giua_ki); ?></p>
                    <p><strong>Điểm cuối kỳ:</strong> <?php echo e($diem->cuoi_ki); ?></p>
                    <p class="fw-bold text-danger"><strong>Điểm trung bình:</strong> <?php echo e($diem->diem_tb); ?></p>

                    
                    <?php if($diem->diem_tb >= 4): ?>
                    <p class="fw-bold text-success"><strong>Kết quả:</strong>✅ Đạt</p>
                    <?php else: ?>
                    <p class="fw-bold text-danger"><strong>Kết quả:</strong> ❌ Không đạt</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="alert alert-warning mt-4" role="alert">
        <i class="bi bi-exclamation-circle-fill me-2"></i>Chưa có điểm cho sinh viên này.
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\student\diem.blade.php ENDPATH**/ ?>