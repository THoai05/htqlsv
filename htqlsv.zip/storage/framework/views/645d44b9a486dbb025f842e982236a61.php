<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <h1 class="text-center mb-4">Danh sách người dùng</h1>

    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <strong>Thành công!</strong> <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary mb-3">Thêm Người Dùng</a>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Họ tên</th>
                <th>password</th>
                <th>Vai trò</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->user_ID); ?></td>
                <td><?php echo e($user->username); ?></td>
                <td><?php echo e($user->password); ?></td>
                <td><?php echo e($user->role); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.users.edit', $user->user_ID)); ?>" class="btn btn-warning btn-sm">
                        <i class="fas fa-pencil-alt"></i> Sửa
                    </a>
                    <form action="<?php echo e(route('admin.users.destroy', $user->user_ID)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Bạn có chắc muốn xóa?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">
                            <i class="fas fa-trash-alt"></i> Xóa
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\admin\users\index.blade.php ENDPATH**/ ?>