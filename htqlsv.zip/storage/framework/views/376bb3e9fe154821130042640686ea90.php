<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="my-4 text-center text-primary">Danh sách giảng viên</h2>

    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Thành công!</strong> <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.giangviens.create')); ?>" class="btn btn-success mb-3">Thêm Giảng Viên</a>

    <div class="table-responsive">
        <table class="table table-hover table-bordered shadow-sm rounded">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Họ tên</th>
                    <th>Mã giảng viên</th>
                    <th>Khoa</th>
                    <th>Email</th>
                    <th>Số điện thoại</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $giangViens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($gv->id); ?></td>
                    <td><?php echo e($gv->ho_ten); ?></td>
                    <td><?php echo e($gv->ma_giang_vien); ?></td>
                    <td><?php echo e($gv->khoa); ?></td>
                    <td><?php echo e($gv->email); ?></td>
                    <td><?php echo e($gv->so_dien_thoai); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.giangviens.edit', ['giangvien' => $gv->id])); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-pencil-alt"></i> Sửa
                        </a>

                        <form action="<?php echo e(route('admin.giangviens.destroy', $gv->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Bạn có chắc chắn muốn xóa?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash-alt"></i> Xóa
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\admin\giangviens\index.blade.php ENDPATH**/ ?>