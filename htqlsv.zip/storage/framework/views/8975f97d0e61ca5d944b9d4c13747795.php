<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.querySelectorAll('.form-dangky').forEach(form => {
            form.addEventListener('submit', function (e) {
                e.preventDefault(); // Chặn submit mặc định

                Swal.fire({
                    title: 'Xác nhận đăng ký',
                    text: 'Bạn có chắc chắn muốn đăng ký học phần này?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Đồng ý',
                    cancelButtonText: 'Huỷ bỏ',
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit(); // Submit nếu người dùng xác nhận
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Các lớp học phần đăng kí</h2>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error1')): ?>
            <div class="alert alert-danger"><?php echo e(session('error1')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        <table class="table table-bordered table-striped">
            <thead class="table-primary">
                <tr>
                    <th>Tên lớp học phần</th>
                    <th>Môn học</th>
                    <th>Số tín chỉ</th>
                    <th>Phòng học</th>
                    <th>Ngày học</th>
                    <th>Tiết bắt đầu</th>
                    <th>Tiết kết thúc</th>
                    <th>Số lượng sinh viên</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $lophocphans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($lop->monhoc->khoa == $sinhvien->khoa): ?>
                        <tr>
                            <td><?php echo e($lop->tenlop); ?></td>
                            <td><?php echo e($lop->monhoc->ten_mon_hoc ?? 'Chưa có'); ?></td>
                            <td><?php echo e($lop->monhoc->so_tin_chi); ?></td>
                            <td><?php echo e($lop->phonghoc->tenphonghoc ?? 'Chưa có'); ?></td>
                            <td><?php echo e($lop->ngayhoc); ?></td>
                            <td><?php echo e($lop->tietbatdau); ?></td>
                            <td><?php echo e($lop->tietketthuc); ?></td>
                            <td><?php echo e($lop->soluongsv); ?>/40</td>
                            <td>
                                <form class="form-dangky"
                                    action="<?php echo e(route('student.dangkilophocphan.store', ['lophoc_ID' => $lop->lophoc_ID, 'sinhvien_ID' => $sinhvien->sinhvien_ID])); ?>"
                                    method="POST" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-info btn-sm"
                                        style="display: inline-flex; align-items: center;">
                                        <img src="<?php echo e(asset('images/find.png')); ?>"
                                            style="width: 20px; height: 20px; margin-right: 5px;" />
                                        Đăng kí
                                    </button>
                                </form>

                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\student\dangkihocphan.blade.php ENDPATH**/ ?>