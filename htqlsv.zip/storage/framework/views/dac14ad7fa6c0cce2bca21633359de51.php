<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Danh sách sinh viên lớp học phần: <?php echo e($lophocphan->tenlop); ?></h1>

    <!-- Form Tìm Kiếm và Lọc -->
    <form method="GET" action="<?php echo e(route('lecturer.lophocphan.sinhvien', $lophocphan->lophoc_ID)); ?>" class="mb-3">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="input-group shadow-sm">
                    <input type="text" name="search" class="form-control rounded-left"
                        placeholder="🔍 Tìm theo MSSV hoặc tên sinh viên"
                        value="<?php echo e(request('search')); ?>">
                    <div class="input-group-append">
                        <button class="btn btn-primary rounded-right" style="margin-left: 20px;" type="submit">
                            Tìm kiếm
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <?php if($sinhviens->isEmpty()): ?>
    <p>Không có sinh viên nào trong lớp học phần này.</p>
    <?php else: ?>
    <a href="<?php echo e(route('lecturer.diem.baocao', ['lophoc_ID' => $lophocphan->lophoc_ID])); ?>" class="btn btn-success mb-3">
        Báo cáo điểm lớp
    </a>

    <a href="<?php echo e(route('lecturer.diemdanh.index', ['lophoc_ID' => $lophocphan->lophoc_ID])); ?>" class="btn btn-primary mb-3">
        Điểm danh lớp
    </a>
    <?php endif; ?>

    <?php if($sinhviens->isEmpty()): ?>
    <p>Không có sinh viên nào trong lớp học phần này.</p>
    <?php else: ?>
    <table class="table">
        <thead>
            <tr>
                <th>MSSV</th>
                <th>Tên Sinh viên</th>
                <th>Điểm</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $sinhviens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sinhvien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($sinhvien->mssv); ?></td>
                <td><?php echo e($sinhvien->hoten); ?></td>
                <td>
                    <!-- Thêm link xem điểm cho sinh viên -->
                    <a href="<?php echo e(route('lecturer.diem.show', ['lophoc_ID' => $lophocphan->lophoc_ID, 'sinhvien_ID' => $sinhvien->sinhvien_ID])); ?>">
                        Xem Điểm
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lecturer.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\lecturer\sinhvien\sinhvien_list.blade.php ENDPATH**/ ?>