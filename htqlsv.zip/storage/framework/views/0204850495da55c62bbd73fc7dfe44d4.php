<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Lịch Học Của Tôi</h2>

    <table class="table table-bordered table-striped">
        <thead class="table-primary">
            <tr>
                <th>Phòng Học</th>
                <th>Thứ 2</th>
                <th>Thứ 3</th>
                <th>Thứ 4</th>
                <th>Thứ 5</th>
                <th>Thứ 6</th>
                <th>Thứ 7</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $lichHoc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phongHoc => $days): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="table-secondary"><strong><?php echo e($phongHoc); ?></strong></td>

                <?php $__currentLoopData = ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td class="table-light">
                    <?php if(isset($days[$day])): ?>
                    <?php $__currentLoopData = $days[$day]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><strong><?php echo e($class['class']); ?></strong></div>
                    <div><?php echo e($class['monhoc']); ?> (<?php echo e($class['sotinchi']); ?> tín chỉ)</div>
                    <div>Tiết: <?php echo e($class['time']); ?></div>
                    <div>Giảng viên: <?php echo e($class['giangvien']); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <div class="text-muted"></div>
                    <?php endif; ?>
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\student\lichhoc.blade.php ENDPATH**/ ?>