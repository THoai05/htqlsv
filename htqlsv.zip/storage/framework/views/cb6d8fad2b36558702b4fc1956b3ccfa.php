<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Quản Lý Lịch Học</h1>
    <!-- Nút chuyển đến trang tạo lớp học phần mới -->
    <a href="<?php echo e(route('admin.lichhoc.create')); ?>" class="btn btn-success mb-3">Thêm Lớp Học Phần</a>

    <?php $__currentLoopData = $monhocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monhoc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mb-4">
        <div class="card-header">
            <h3><?php echo e($monhoc->ten_mon_hoc); ?> (<?php echo e($monhoc->ma_mon_hoc); ?>)</h3>
            <p>Số tín chỉ: <?php echo e($monhoc->so_tin_chi); ?></p>
        </div>
        <div class="card-body">
            <?php if($monhoc->lophocphans->count() > 0): ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Tên Lớp</th>
                        <th>Phòng Học</th>
                        <th>Giảng Viên</th>
                        <th>Số SV</th>
                        <th>Thời Gian</th>
                        <th>Ngày Học</th>
                        <th>Tiết (Bắt đầu - Kết thúc)</th>
                        <th>Hành Động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $monhoc->lophocphans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lophocphan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($lophocphan->tenlop); ?></td>
                        <td><?php echo e($lophocphan->phonghoc->tenphonghoc ?? 'N/A'); ?></td>
                        <td><?php echo e($lophocphan->giangvien->ho_ten ?? 'N/A'); ?></td>
                        <td><?php echo e($lophocphan->soluongsv); ?></td>
                        <td><?php echo e($lophocphan->thoigianbatdau); ?> - <?php echo e($lophocphan->thoigianketthuc); ?></td>
                        <td><?php echo e($lophocphan->ngayhoc); ?></td>
                        <td><?php echo e($lophocphan->tietbatdau); ?> - <?php echo e($lophocphan->tietketthuc); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.lichhoc.edit', $lophocphan->lophoc_ID)); ?>"
                                class="btn btn-warning btn-sm">Sửa</a>
                            <form action="<?php echo e(route('admin.lichhoc.destroy', $lophocphan->lophoc_ID)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button onclick="return confirm('Bạn có chắc muốn xóa?')" type="submit"
                                    class="btn btn-danger btn-sm">Xóa</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php else: ?>
            <p>Chưa có lớp học phần cho môn này.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\admin\lichhoc\index.blade.php ENDPATH**/ ?>