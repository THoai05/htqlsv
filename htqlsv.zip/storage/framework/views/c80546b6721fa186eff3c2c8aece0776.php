<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Điểm của Sinh Viên</h1>
</div>
<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>
<?php if($diem): ?>
<p><strong>Điểm hiện tại:</strong></p>
<ul>
    <li>Điểm 15p 1: <?php echo e($diem->diem_15p_1); ?></li>
    <li>Điểm 15p 2: <?php echo e($diem->diem_15p_2); ?></li>
    <li>Điểm 15p 3: <?php echo e($diem->diem_15p_3); ?></li>
    <li>Điểm giữa kỳ: <?php echo e($diem->giua_ki); ?></li>
    <li>Điểm cuối kỳ: <?php echo e($diem->cuoi_ki); ?></li>
    <li><strong>Điểm trung bình:</strong> <?php echo e($diem->diem_tb); ?></li>
</ul>
<?php else: ?>
<p><strong>Chưa có điểm cho sinh viên này.</strong></p>
<?php endif; ?>

<h3>Nhập hoặc sửa điểm</h3>
<form action="<?php echo e(route('lecturer.diem.save', ['lophoc_ID' => $lophoc_ID, 'sinhvien_ID' => $sinhvien_ID])); ?>"
    method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="diem_15p_1">Điểm 15p 1</label>
        <input type="number" name="diem_15p_1" class="form-control" step="0.01" min="0" max="10"
            value="<?php echo e($diem->diem_15p_1 ?? ''); ?>" required>
    </div>
    <div class="form-group">
        <label for="diem_15p_2">Điểm 15p 2</label>
        <input type="number" name="diem_15p_2" class="form-control" step="0.01" min="0" max="10"
            value="<?php echo e($diem->diem_15p_2 ?? ''); ?>" required>
    </div>
    <div class="form-group">
        <label for="diem_15p_3">Điểm 15p 3</label>
        <input type="number" name="diem_15p_3" class="form-control" step="0.01" min="0" max="10"
            value="<?php echo e($diem->diem_15p_3 ?? ''); ?>" required>
    </div>
    <div class="form-group">
        <label for="giua_ki">Điểm giữa kỳ</label>
        <input type="number" name="giua_ki" class="form-control" step="0.01" min="0" max="10"
            value="<?php echo e($diem->giua_ki ?? ''); ?>" required>
    </div>
    <div class="form-group">
        <label for="cuoi_ki">Điểm cuối kỳ</label>
        <input type="number" name="cuoi_ki" class="form-control" step="0.01" min="0" max="10"
            value="<?php echo e($diem->cuoi_ki ?? ''); ?>" required>
    </div>
    <br>
    <button type="submit" class="btn btn-primary">Lưu điểm</button>
    <button type="button" class="btn btn-secondary" onclick="window.history.back()">Quay lại</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lecturer.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\lecturer\sinhvien\sinhvien_diem.blade.php ENDPATH**/ ?>