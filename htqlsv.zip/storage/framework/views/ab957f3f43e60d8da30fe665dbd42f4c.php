<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Chỉnh Sửa Sinh Viên</h2>

        <form action="<?php echo e(route('admin.sinhvien.update', $sinhvien->sinhvien_ID)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label>Họ Tên:</label>
                <input type="text" name="hoten" value="<?php echo e($sinhvien->hoten); ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label>MSSV:</label>
                <input type="text" name="mssv" value="<?php echo e($sinhvien->mssv); ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" value="<?php echo e($sinhvien->email); ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label>SĐT:</label>
                <input type="text" name="sdt" value="<?php echo e($sinhvien->sdt); ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Căn cước công dân:</label>
                <input type="text" name="cccd" value="<?php echo e($sinhvien->cccd); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label>Ngày sinh:</label>
                <input type="date" name="ngaysinh"
                    value="<?php echo e($sinhvien->ngaysinh ? \Carbon\Carbon::parse($sinhvien->ngaysinh)->format('Y-m-d') : ''); ?>"
                    class="form-control">
            </div>
            <div class="form-group">
                <label>Giới tính:</label>
                <select name="gioitinh" class="form-control">
                    <option value="Nam" <?php echo e($sinhvien->gioitinh == 'Nam' ? 'selected' : ''); ?>>Nam</option>
                    <option value="Nữ" <?php echo e($sinhvien->gioitinh == 'Nữ' ? 'selected' : ''); ?>>Nữ</option>
                </select>
            </div>
            <div class="form-group">
                <label>Dân tộc:</label>
                <input type="text" name="dantoc" value="<?php echo e($sinhvien->dantoc); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label>Tôn giáo:</label>
                <input type="text" name="tongiao" value="<?php echo e($sinhvien->tongiao); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label>Nơi sinh:</label>
                <input type="text" name="noisinh" value="<?php echo e($sinhvien->noisinh); ?>" class="form-control">
            </div>
            <div class="form-group">
                <label>Tình trạng:</label>
                <input type="text" name="tinhtrang" value="<?php echo e($sinhvien->tinhtrang); ?>" class="form-control">
            </div>

            <button type="submit" class="btn btn-success">Cập Nhật</button>
            <a href="<?php echo e(route('admin.sinhvien.index')); ?>" class="btn btn-secondary">Hủy</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\admin\sinhvien\edit.blade.php ENDPATH**/ ?>