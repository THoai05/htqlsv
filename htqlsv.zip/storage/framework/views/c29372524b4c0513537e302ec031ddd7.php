<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Lịch dạy của tôi</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tên lớp học phần</th>
                <th>Môn học</th>
                <th>Phòng học</th>
                <th>Ngày học</th>
                <th>Tiết bắt đầu</th>
                <th>Tiết kết thúc</th>
                <th>Hành động</th> <!-- Cột mới -->
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $lophocphans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($lop->tenlop); ?></td>
                <td><?php echo e($lop->monhoc->ten_mon_hoc ?? 'Chưa có'); ?></td>
                <td><?php echo e($lop->phonghoc->tenphonghoc ?? 'Chưa có'); ?></td>
                <td><?php echo e($lop->ngayhoc); ?></td>
                <td><?php echo e($lop->tietbatdau); ?></td>
                <td><?php echo e($lop->tietketthuc); ?></td>
                <td>
                    <!-- Thêm nút để xem danh sách sinh viên -->
                    <a href="<?php echo e(route('lecturer.lophocphan.sinhvien', $lop->lophoc_ID)); ?>" class="btn btn-primary align-items-center">
                        <img src="<?php echo e(asset('images/32.png')); ?>" style="width: 24px; height: 24px;margin-right: 5px;" alt="Xem sinh viên">Xem Sinh Viên
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lecturer.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\lecturer\sinhvien\lophocphan_list.blade.php ENDPATH**/ ?>