<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Thêm Môn Học</h2>

    <form action="<?php echo e(route('admin.monhocs.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Tên Môn Học</label>
            <input type="text" name="ten_mon_hoc" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Mã Môn Học</label>
            <input type="text" name="ma_mon_hoc" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Số Tín Chỉ</label>
            <input type="number" name="so_tin_chi" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Lưu</button>
        <a href="<?php echo e(route('admin.monhocs.index')); ?>" class="btn btn-secondary">Hủy</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\admin\monhocs\create.blade.php ENDPATH**/ ?>