<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Chỉnh sửa Môn Học</h2>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.monhocs.update', $monhoc->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label class="form-label">Tên môn học</label>
            <input type="text" name="ten_mon_hoc" class="form-control" value="<?php echo e(old('ten_mon_hoc', $monhoc->ten_mon_hoc)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Mã môn học</label>
            <input type="text" name="ma_mon_hoc" class="form-control" value="<?php echo e(old('ma_mon_hoc', $monhoc->ma_mon_hoc)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Số tín chỉ</label>
            <input type="number" name="so_tin_chi" class="form-control" value="<?php echo e(old('so_tin_chi', $monhoc->so_tin_chi)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Giảng viên</label>
            <select name="giang_vien_id" class="form-control" required>
                <?php $__currentLoopData = $giangviens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $giangvien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($giangvien->id); ?>" <?php echo e($monhoc->giang_vien_id == $giangvien->id ? 'selected' : ''); ?>>
                    <?php echo e($giangvien->ho_ten); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Cập nhật</button>
        <a href="<?php echo e(route('admin.monhocs.index')); ?>" class="btn btn-secondary">Hủy</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\admin\monhocs\edit.blade.php ENDPATH**/ ?>