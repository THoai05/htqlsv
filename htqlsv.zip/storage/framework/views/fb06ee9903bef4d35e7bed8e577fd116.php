<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Danh Sách Sinh Viên</h2>
        <a href="<?php echo e(route('admin.sinhvien.create')); ?>" class="btn btn-primary mb-3">Thêm Sinh Viên</a>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Họ Tên</th>
                    <th>MSSV</th>
                    <th>Email</th>
                    <th>SĐT</th>
                    <th>Căn Cước Công Dân</th>
                    <th>Ngày Sinh</th>
                    <th>Giới Tính</th>
                    <th>Dân Tộc</th>
                    <th>Tôn Giáo</th>
                    <th>Nơi Sinh</th>
                    <th>Tình Trạng</th>
                    <th>Hành Động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sinhviens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($sv->sinhvien_ID); ?></td>
                        <td><?php echo e($sv->hoten); ?></td>
                        <td><?php echo e($sv->mssv); ?></td>
                        <td><?php echo e($sv->email); ?></td>
                        <td><?php echo e($sv->sdt); ?></td>
                        <td><?php echo e($sv->cccd); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($sv->ngaysinh)->format('d/m/Y')); ?></td>
                        <td><?php echo e($sv->gioitinh); ?></td>
                        <td><?php echo e($sv->dantoc); ?></td>
                        <td><?php echo e($sv->tongiao); ?></td>
                        <td><?php echo e($sv->noisinh); ?></td>
                        <td><?php echo e($sv->tinhtrang); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.sinhvien.edit', ['sinhvien' => $sv->sinhvien_ID])); ?>"
                                class="btn btn-warning">Sửa</a>
                            <form action="<?php echo e(route('admin.sinhvien.destroy', $sv->sinhvien_ID)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Bạn có chắc chắn muốn xóa?')">Xóa</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\admin\sinhvien\index.blade.php ENDPATH**/ ?>