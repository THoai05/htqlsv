<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Báo cáo điểm lớp học phần: <?php echo e($lophoc->tenlop); ?></h1>
    <form method="GET" action="<?php echo e(route('lecturer.diem.baocao', ['lophoc_ID' => $lophoc_ID])); ?>" class="mb-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="input-group shadow-sm">
                    <input type="text" name="search" class="form-control rounded-left"
                        placeholder="🔍 Tìm theo MSSV hoặc tên sinh viên"
                        value="<?php echo e(request('search')); ?>">
                    <div class="input-group-append">
                        <button class="btn btn-primary rounded-right" style="margin-left: 20px;" type="submit">
                            Tìm kiếm
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>


    <table class="table table-bordered">
        <thead>
            <tr>
                <th>MSSV</th>
                <th>Họ tên</th>
                <th>15p 1</th>
                <th>15p 2</th>
                <th>15p 3</th>
                <th>Giữa kỳ</th>
                <th>Cuối kỳ</th>
                <th>Trung bình</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $danhsach; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($sv->mssv); ?></td>
                <td><?php echo e($sv->hoten); ?></td>
                <td><?php echo e($sv->diem_15p_1); ?></td>
                <td><?php echo e($sv->diem_15p_2); ?></td>
                <td><?php echo e($sv->diem_15p_3); ?></td>
                <td><?php echo e($sv->giua_ki); ?></td>
                <td><?php echo e($sv->cuoi_ki); ?></td>
                <td><strong><?php echo e($sv->diem_tb); ?></strong></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lecturer.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin\htqlsv\resources\views\lecturer\sinhvien\baocao_diem.blade.php ENDPATH**/ ?>